source(here::here("scrawl","scrawl_functions.R"))

art <- list(
  seed = 9,        # RNG seed
  n_paths = 200000,    # number of paths
  n_steps = 5,    # number of steps
  sz_step = 500,     # step size 
  sz_slip = 500,      # slip size
  palette = "grayC"   # which scico palette
)

# ensure R is in an appropriate state
scrawl_setup(options = art) 

# create your artwork in a three-step pipe!
scrawl_build(options = art) %>% 
  scrawl_plot(options = art) %>% 
  scrawl_save(options = art)