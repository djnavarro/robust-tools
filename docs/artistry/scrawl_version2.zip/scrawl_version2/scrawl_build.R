scrawl_build <- function(options) {
  
  scrawl <- scrawl_new(options = options)
  state <- scrawl
  
  for(step in 1:options$n_steps) {
    state <- scrawl_modify(state = state, options = options)
    scrawl <- bind_rows(scrawl, state)
  }
  
  return(scrawl)
}
