# Author: Danielle Navarro
# Date: 2020-04-08

# Functions that are used to create a "scrawl" artwork (version 2). There are
# four functions that we expect the user to make use of, each of which is in 
# a separate file (not my usual practice!)
#
# - scrawl_setup: initialises the R state
# - scrawl_build: iteratively builds the data for a scrawl 
# - scrawl_plot:  takes the scrawl data and creates a plot object
# - scrawl_save:  saves a scrawl plot to an image file

source(here::here("scrawl", "scrawl_setup.R"))
source(here::here("scrawl", "scrawl_build.R"))
source(here::here("scrawl", "scrawl_plot.R"))
source(here::here("scrawl", "scrawl_save.R"))

# There are two functions that we don't expect the user to need. These functions
# are both called by scrawl_build()
#
# - scrawl_new:     initialises the scrawl state 
# - scrawl_modify:  modifies a scrawl state via curl noise

source(here::here("scrawl", "scrawl_new.R"))
source(here::here("scrawl", "scrawl_modify.R"))

# Note: there are a few respects in which what I'm doing here is not "best 
# practice". Later in the class we'll revisit this and improve it.
