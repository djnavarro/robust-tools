scrawl_modify <- function(state, options) {
  
  # Use the curl_noise function from the ambient package to select 
  # directions/distances to "step" each of the brushes in 3D space 
  step <- curl_noise(
    generator = gen_simplex,
    x = state$x,
    y = state$y,
    z = state$z,
    seed = c(1, 1, 1) * options$seed
  )
  
  # Use the "step" data to mutate/modify the current state
  state <- state %>% 
    mutate(
      x = x + step$x * options$sz_step / 10000, # step along x
      y = y + step$y * options$sz_step / 10000, # step along y
      z = z + step$z * options$sz_slip / 10000, # step along z
      step_id = step_id + 1                     # increment the step number!
    )
  
  # Return the modified state to the user
  return(state)
}
