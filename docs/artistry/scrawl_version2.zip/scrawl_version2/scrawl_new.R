scrawl_new <- function(options) {
  
  # To start drawing our scrawl we need to specify the "state" of the picture
  # after the first "step". Each of the paths starts at a random location on 
  # the canvas (varibles: x and y), and has a hidden z co-ordinate that is 
  # initially set to 0 for every path.
  state <- tibble(
    x = runif(options$n_paths, min = 0, max = 2), # uniform between 0 and 2
    y = runif(options$n_paths, min = 0, max = 2), # uniform between 0 and 2
    z = 0
  )
  
  # It is good practice to assign each path a specific identifier number (path_id)
  # and similarly we should assign each step its own id (this is the first step so
  # step_id = 1 for all paths)
  state <- state %>% 
    mutate(
      path_id = 1:options$n_paths,
      step_id = 1
    )
  
  # return the initial state to the user  
  return(state)
}
