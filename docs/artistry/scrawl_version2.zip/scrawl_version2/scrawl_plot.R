scrawl_plot <- function(data, options) {
  
  picture <- ggplot(
    data = data,        # the data
    mapping = aes(
      x = x,            # plot the x-value
      y = y,            # plot the y-value
      group = path_id,  # each "path_id" is a distinct group 
      color = step_id   # paths change color as they step along
    )
  ) + 
    geom_path(
      size = .5,     # width of the lines
      alpha = .5,    # transparency of the lines
      show.legend = FALSE
    ) + 
    coord_equal() +  # ensure x and y coordinates are on the same scale 
    theme_void() +   # use a blank theme 
    scale_color_scico(palette = options$palette) # set the color scheme
  
  return(picture)
}
