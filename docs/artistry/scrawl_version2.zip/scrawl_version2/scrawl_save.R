scrawl_save <- function(picture, options, pixels_wide = 5000, pixels_high = 5000) {
  
  # what shall we call our image?
  filename <- options %>% 
    str_c(collapse = "-") %>% 
    str_c("scrawl_", ., ".png", collapse = "-")
  
  # save it it to file
  ggsave(
    filename = filename,        # the filename
    path = here("img"),         # the folder to save it in
    plot = picture,             # the ggplot object to draw to the file
    width = pixels_wide / 300,  # width of the image in "inches"
    height = pixels_high / 300, # height of the image in "inches"
    dpi = 300                   # dpi = "dots (pixels) per inch"  
  )
  
  # this is a function called only for its side effects
  return(invisible(NULL))
}
