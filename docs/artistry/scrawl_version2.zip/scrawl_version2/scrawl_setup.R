scrawl_setup <- function(options) {
  
  # load the packages we need
  library(tidyverse)
  library(ambient) 
  library(scico)
  library(here)
  
  # set the seed
  set.seed(options$seed) 
  
  # "returns" nothing
  return(invisible(NULL))
}
