# Exercise 3
#
# She has done it again. It looks like she's replaced all the argument names
# with smiley faces. Can please fix this one too? 

# Our first script --------------------------------------------------------

library(tidyverse)

dino <- read_csv("data_dino.csv")
print(💖)

# Create a new "picture"...
picture <- ggplot(🙂 = 💖) + 
  geom_point(🙂 = aes(🙂 = 💖, 🙂 = 💖))

# ... and plot it
plot(💖)
